# Dahar Mas
## Repo ini adalah bagian dari Tugas Akhir Rekayasa Perangkat Lunak Semester Group A Genap 2022/2023.

Dahar Mas adalah aplikasi yang digunakan untuk mencari tempat makan. Pencarian tempat makan dalam aplikasi ini memiliki beberapa fitur, seperti pencarian berdasarkan kategori, kata kunci, dan rekomendasi tempat makan terbaik.

### Anggota:
1. Stefanus Yandi Prakosa (71210683)
2. Kaleb Coyo Wagito (71210686)
3. Glen Angelo T Hamdani (71210803)

### Fungsi dalam aplikasi:
1. Menampilkan 10 tempat makan terbaik berdasarkan rating.
2. Pencarian berdasarkan kata kunci.
3. Pencarian berdasarkan kategori.
